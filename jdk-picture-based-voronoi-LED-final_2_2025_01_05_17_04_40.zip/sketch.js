// Coding Train / Daniel Shiffman
// Weighted Voronoi Stippling
// https://thecodingtrain.com/challenges/181-image-stippling

// jdk 수정

let points = [];
let delaunay, voronoi;
let bgImg;
let offsetX, offsetY, offsetW, offsetH

let colorPalettes = {}; // JSON 색상 데이터를 저장할 배열
let selectedPalette; // 선택된 색상 팔레트
let randomIndex;


function preload() {
  // JSON 파일 로드 (예: colorPalettes.json)
  colorPalettes = loadJSON("./colors.json");
  // 배경 이미지
  bgImg = loadImage("sanfrancisco-California-reflection-church-architecture-Raw-962960-wallhere.com-square-투명2.png");
}

function setup() {
  createCanvas(bgImg.width, bgImg.height);
  background(bgImg);
  //console.log("cp", colorPalettes.length);
  
  // offsetX = width / 3.5;
  // offsetY = height / 4.84;
  // offsetW = width / 1.359;
  // offsetH = height / 1.937;
 
  offsetX = 260;
  offsetY = 160;
  offsetW = 800;
  offsetH = 550;
   console.log(offsetX, offsetY, offsetW, offsetH);
  
  
  //console.log(width/2, height/2);
  
  generateVoronoi(); // 초기 Voronoi 다이어그램 생성

  // 3초마다 새로운 Voronoi 다이어그램 생성
  setInterval(generateVoronoi, 6000);
}

function generateVoronoi() {
  
  if (Object.keys(colorPalettes).length >= 0) {
    // 랜덤으로 색상 팔레트를 선택
    randomIndex = floor(random(Object.keys(colorPalettes).length));
    selectedPalette = colorPalettes[randomIndex];
  }
   // console.log("Selected Palette Index:", randomIndex, "Palette:", Object.keys(colorPalettes).length, selectedPalette.length);
  

  // 새로운 포인트 배열 생성
  points = [];
  for (let i = 0; i < 75; i++) {
    let x = random(width);
    let y = random(height);
    // let x = random(rectX1, rectX3);
    // let y = random(rectY1, rectY3);
    points[i] = createVector(x, y);
  }

  // Delaunay 및 Voronoi 갱신
  delaunay = calculateDelaunay(points);
  voronoi = delaunay.voronoi([offsetX, offsetY, offsetW, offsetH]);

  drawVoronoi();
}

function drawVoronoi() {
  let polygons = voronoi.cellPolygons();
  let cells = Array.from(polygons);

  for (let poly of cells) {
    stroke(255);
    strokeWeight(2);
    
    if (poly.length > 0) {
      drawPerlinGradientPolygon(poly);
    }
  }
}

function hexToHSB(hex) {
  // HEX 색상을 HSB로 변환
  colorMode(RGB, 255);
  let c = color(hex);
  colorMode(HSB, 360, 100, 100);
  return {
    h: hue(c),
    s: saturation(c),
    b: brightness(c)
  };
}

function drawPerlinGradientPolygon(polygon) {
  // 노이즈 적용을 위한 기준 값
  let noiseScale = 0.01;

  // 다각형의 경계 좌표 계산
  let xMin = Infinity, xMax = -Infinity, yMin = Infinity, yMax = -Infinity;
  for (let v of polygon) {
    xMin = min(xMin, v[0]);
    xMax = max(xMax, v[0]);
    yMin = min(yMin, v[1]);
    yMax = max(yMax, v[1]);
  }

  // 그라디언트 설정
  let gradient = drawingContext.createLinearGradient(xMin, yMin, xMax, yMax);
  
  // 선택된 팔레트에서 색상 선택
  let baseColorHex = selectedPalette[floor(random(selectedPalette.length))];
  let baseColorHSB = hexToHSB(baseColorHex);

  // 랜덤 색상 생성 (HSB 모드 사용)
  colorMode(HSB, 360, 100, 100);
  let baseColor = color(baseColorHSB.h, baseColorHSB.s, baseColorHSB.b);
  let darkColor = color(baseColorHSB.h, baseColorHSB.s, baseColorHSB.b * 0.3);
  

  gradient.addColorStop(0, baseColor.toString());
  gradient.addColorStop(0.5, baseColor.toString());
  gradient.addColorStop(0.8, darkColor.toString());
  gradient.addColorStop(1, darkColor.toString());

  // 다각형 내부에 펄린 노이즈로 변형된 색상 적용
  drawingContext.fillStyle = gradient;
  beginShape();
  for (let v of polygon) {
    let noiseX = v[0] + noise(v[0] * noiseScale, v[1] * noiseScale) * 20;
    let noiseY = v[1] + noise(v[0] * noiseScale, v[1] * noiseScale) * 20;
    vertex(noiseX, noiseY);
  }
  endShape(CLOSE);

  // RGB 모드 복원
  colorMode(RGB, 255);
  
  background(bgImg); // 백그라운드 이미지 
}

function calculateDelaunay(points) {
  let pointsArray = [];
  for (let v of points) {
    pointsArray.push(v.x, v.y);
  }
  return new d3.Delaunay(pointsArray);
}

